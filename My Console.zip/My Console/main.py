from ai import call_gpt

def main():
    print( "****WELCOME****".center(74))
    print("To".center(73))
    print("\tAI  Assistant  Chatbot :)".center(70),"\n")
    print(" __How can I help??__".center(70))
    

    while True:
        topic = input("\nAsk anything: ")

        if topic.lower() == "exit":
            print("Bot: Goodbye!")
            print("------------------------")
            break

        response = call_gpt(topic)
        print("Bot:", response,"\n If you want more i can help..........")
   
if __name__ == "__main__":
    main()